<?php

namespace App\Http\Controllers;

use App\Models\Gigs;
use App\Models\GigTags;
use App\Models\PackageSpec;
use Illuminate\Http\Request;

class GigsController extends Controller
{
    /**
     * Create a gig and give it tags.
     *
     * @param  \Illuminate\Http\Request  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $gig = Gigs::firstOrCreate([
            'title' => $request['gigTitle'],
            'sub_category_id' => $request['subCategoryId'],
            'description' => $request['description'],
            'requirements'=> $request['requirements'],
            'slug' => str_replace(' ', '_', $request['gigTitle']),
            'user_id'=> $request['userId']
        ]);

        $tags = $request['tags'];
        foreach ($tags as $tag){
            GigTags::firstOrCreate(
                ["tag_title" => $tag,],
                ['gig_id' => $gig->id]
            );
        }
        return response(["message" => "success", "gig_id"=>$gig->id]);
    }

     /**
     * Logout the specified User Logged in.
     *
     * @param  \Illuminate\Http\Request  $request
     *
     * @return \Illuminate\Http\Response
     */
    public function createProduct(Request $request){
        //
    }

     /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function viewPackageSpec(Request $request, $id){

        return response()
    }

}
